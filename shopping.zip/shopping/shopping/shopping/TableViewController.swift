//
//  File.swift
//  shopping
//
//  Created by User14 on 2018/10/24.
//  Copyright © 2018 MAC. All rights reserved.
//

import UIKit

class TableViewController: UITableViewController {

    @IBOutlet weak var Count1: UITextView!
    @IBOutlet weak var Count2: UITextView!
    @IBOutlet weak var Count3: UITextView!
    @IBOutlet weak var Count4: UITextView!
    
    @IBOutlet weak var Total: UILabel!
    
    var nowCount1:Int = 0
    var nowCount2:Int = 0
    var nowCount3:Int = 0
    var nowCount4:Int = 0

    @IBAction func Stepper1(_ sender: UIStepper) {
        nowCount1 = Int(sender.value)
        Count1.text = "\(nowCount1)"
        tolalPrice()
    }
    
    @IBAction func Stepper2(_ sender: UIStepper) {
        nowCount2 = Int(sender.value)
        Count2.text = "\(nowCount2)"
        tolalPrice()
    }
    
    @IBAction func Stepper3(_ sender: UIStepper) {
            nowCount3 = Int(sender.value)
            Count3.text = "\(nowCount3)"
            tolalPrice()
    }
    
    @IBAction func Stepper4(_ sender: UIStepper) {
        nowCount4 = Int(sender.value)
        Count4.text = "\(nowCount4)"
        tolalPrice()
    }
    
    func tolalPrice(){
        let sum = 35900 * nowCount1 + 25000 * nowCount2 + 400 * nowCount3 + 275 * nowCount4
        Total.text = "$  " + "\(sum)"
    }


    
    @IBOutlet weak var show: UIImageView!
    
    @IBAction func Button1(_ sender: UIButton) {
        show.image = UIImage(named:"show1")
    }
    
    @IBAction func Button2(_ sender: UIButton) {
        show.image = UIImage(named:"show2")
    }
    
    @IBAction func Button3(_ sender: UIButton) {
        show.image = UIImage(named:"show3")
    }
    
    @IBAction func Button4(_ sender: UIButton) {
        show.image = UIImage(named:"show4")
    }
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }
    
    // MARK: - Table view data source
    
    
    
    /*
     override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
     let cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath)
     
     // Configure the cell...
     
     return cell
     }
     */
    
    /*
     // Override to support conditional editing of the table view.
     override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
     // Return false if you do not want the specified item to be editable.
     return true
     }
     */
    
    /*
     // Override to support editing the table view.
     override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
     if editingStyle == .delete {
     // Delete the row from the data source
     tableView.deleteRows(at: [indexPath], with: .fade)
     } else if editingStyle == .insert {
     // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
     }
     }
     */
    
    /*
     // Override to support rearranging the table view.
     override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {
     
     }
     */
    
    /*
     // Override to support conditional rearranging of the table view.
     override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
     // Return false if you do not want the item to be re-orderable.
     return true
     }
     */
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}

    
    
    
    
    

